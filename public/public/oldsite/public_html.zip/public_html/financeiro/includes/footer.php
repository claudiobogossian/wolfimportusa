
 <!-- jQuery Version 1.11.0 -->
    <script src="js/jquery-1.11.0.js"></script>
	
	<!--<script src="js/migrate.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="js/plugins/metisMenu/metisMenu.min.js"></script>
	<script src="js/plugins/fullcalender/lib/moment.min.js"></script>
	<script src="js/plugins/fullcalender/fullcalendar.min.js"></script>
	<!--<script src="js/plugins/qtip/jquery.qtip.min.js"></script>
	
	
    <!-- Morris Charts JavaScript -->
    <script src="js/plugins/morris/raphael.min.js"></script>
    <script src="js/plugins/morris/morris.min.js"></script>
    <script src="js/plugins/morris/morris-data.js"></script>

     <!-- Datepicker JavaScript -->
     <script src="js/bootstrap-datepicker.js"></script>
       
    <!-- DataTables JavaScript -->
    <script src="js/plugins/dataTables/jquery.dataTables.js"></script>
    <script src="js/plugins/dataTables/dataTables.bootstrap.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="js/sb-admin-2.js"></script>

     <script>
    
        $('#income .input-group.date').datepicker({
            autoclose: true,
            format: "yyyy-mm-dd",
            todayHighlight: true
        });
        $('#expense .input-group.date').datepicker({
            autoclose: true,
            format: "yyyy-mm-dd",
            todayHighlight: true
        });
   
    </script>
</body>
</html>
