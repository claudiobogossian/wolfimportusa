jQuery(function($){	
		
	var $window = $(window),
	$body = $('body');		
		
	$('.header_img').prepend('<div id="particles-js"></div>');
		
	 /* wow
	-------------------------------*/
	new WOW({ mobile: false }).init();
		
});
